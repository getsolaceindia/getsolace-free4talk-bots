console.log("GetSolace Free4Talk Chat Bot content.js loaded!");

// ============================================================================
// PERSISTENT MESSAGE TRACKING
// ============================================================================

let repliedMessageIds = new Set();

async function loadRepliedIds() {
  const result = await chrome.storage.local.get('repliedMessageIds');
  if (result.repliedMessageIds && Array.isArray(result.repliedMessageIds)) {
    repliedMessageIds = new Set(result.repliedMessageIds);
    console.log(`✅ Loaded ${repliedMessageIds.size} replied message IDs from storage`);
  }
}

async function saveRepliedIds() {
  const MAX_STORED_IDS = 1000; 
  let idsArray = Array.from(repliedMessageIds);
  
  if (idsArray.length > MAX_STORED_IDS) {
    idsArray = idsArray.slice(-MAX_STORED_IDS);
    repliedMessageIds = new Set(idsArray);
  }
  
  await chrome.storage.local.set({ repliedMessageIds: idsArray });
}

function markAsReplied(messageId) {
  if (!messageId) return;
  repliedMessageIds.add(messageId);
  saveRepliedIds();
}

function hasRepliedTo(messageId) {
  return messageId && repliedMessageIds.has(messageId);
}

// ============================================================================
// CRITICAL FIX: Prevent multiple script injection
// ============================================================================

if (window.hasOwnProperty('__FREE4TALK_BOT_LOADED__')) {
  console.warn('⚠️ Free4Talk bot content script already loaded, skipping re-initialization');
  throw new Error('Script already loaded');
}
window.__FREE4TALK_BOT_LOADED__ = true;

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

let botUserName = 'ChatBot';
let excludedUsernames = [];
let ignoreSelfMessages = true;
let messageDetectorInterval = null;
let isDetectorRunning = false;

// ============================================================================
// INITIALIZATION
// ============================================================================

chrome.storage.local.get([
  'botUsername',
  'friendsList',
  'ignoreSelfMessages',
  'excludedUsernames'
], (result) => {
  botUserName = result.botUsername || botUserName;
  excludedUsernames = result.excludedUsernames || [];
  ignoreSelfMessages = (result.ignoreSelfMessages !== undefined) ? result.ignoreSelfMessages : true;
  console.log('content: config loaded', { botUserName, excludedUsernames, ignoreSelfMessages });
});

chrome.runtime.sendMessage({ 
  type: 'CONTENT_SCRIPT_READY',
  tabId: chrome.runtime.id 
}).catch(err => {
  console.log('Background script not ready yet:', err);
});

// ============================================================================
// MESSAGE LISTENERS
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'CONFIG_UPDATED') {
    const data = request.data || {};
    if (data.botUsername) botUserName = data.botUsername;
    if (data.ignoreSelfMessages !== undefined) ignoreSelfMessages = data.ignoreSelfMessages;
    if (data.excludedUsernames) excludedUsernames = data.excludedUsernames;
    console.log('content: CONFIG_UPDATED received', { botUserName, excludedUsernames, ignoreSelfMessages });
  }

  if (request.type === 'SEND_REPLY') {
    const { text, originalMessage } = request.data;
    const messageId = originalMessage?.messageId;
    
    if (messageId) {
      setupReplyToMessage(messageId).then(() => {
        sendReplyMessage(text, originalMessage?.isPM || false);
      });
    } else {
      sendReplyMessage(text, false);
    }
    
    sendResponse({ success: true });
    return true;
  }

  if (request.type === 'REACT_EMOJI') {
    const { messageId, reactionName } = request.data;
    reactToMessage(messageId, reactionName);
    sendResponse({ success: true });
    return true;
  }
  
  if (request.type === 'BOT_STATUS_CHANGED') {
    const { enabled } = request.data;
    if (enabled && !isDetectorRunning) {
      startMessageDetector();
    } else if (!enabled && isDetectorRunning) {
      stopMessageDetector();
    }
    sendResponse({ success: true });
    return true;
  }
});

// ============================================================================
// DOM HELPERS
// ============================================================================

function selectChatInputBox() {
  return document.querySelector('.input-send-box textarea');
}

function selectSendButton() {
  return document.querySelector('.input-send-box button[type="button"]');
}

function sleep(ms) {
  return new Promise(res => setTimeout(res, ms));
}

// ============================================================================
// MESSAGE SENDING
// ============================================================================

async function sendReplyMessage(message, shouldCancelPM = false) {
  try {
    const chatInput = selectChatInputBox();
    if (!chatInput) {
      console.error('chatInput not found');
      return false;
    }

    chatInput.value = message;
    chatInput.dispatchEvent(new Event('input', { bubbles: true }));
    
    if (chatInput.value !== message) {
      console.warn('Direct value assignment failed, trying alternative method');
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype,
        'value'
      ).set;
      nativeInputValueSetter.call(chatInput, message);
      chatInput.dispatchEvent(new Event('input', { bubbles: true }));
    }

    setTimeout(async () => {
      const sendButton = selectSendButton();
      if (sendButton && sendButton.offsetParent !== null) {
        sendButton.click();
        console.log('✅ Message sent:', message.substring(0, 50) + '...');

        if (shouldCancelPM) {
          await sleep(500);
          await cancelPMMode();
        }
      } else {
        console.warn('⚠️ Send button not found or not visible');
      }
    }, 100);
    
    return true;
  } catch (error) {
    console.error('Error sending reply:', error);
    return false;
  }
}

async function setupReplyToMessage(messageId) {
  const msg = document.querySelector(`[data-message-id="${messageId}"]`);
  if (!msg) {
    console.log("Original message not found for reply setup:", messageId);
    return;
  }

  msg.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
  await sleep(500);

  const replyBtn = Array.from(msg.querySelectorAll("button")).find(btn => {
    const span = btn.querySelector("span");
    return span && span.textContent?.toLowerCase().includes("reply");
  });

  if (replyBtn && replyBtn.offsetParent !== null) {
    replyBtn.click();
    console.log("✅ Reply setup successful for message:", messageId);
  } else {
    console.log("⚠️ Reply button not found for message:", messageId);
  }
}

async function cancelPMMode() {
  try {
    const pmCancelButton = document.querySelector('button.ant-btn.ant-btn-text.ant-btn-sm.ant-btn-icon-only');
    if (pmCancelButton) {
      pmCancelButton.click();
      console.log('PM mode cancelled');
    }
  } catch (error) {
    console.error('Error cancelling PM mode:', error);
  }
}

async function reactToMessage(messageId, reactionName) {
  if (!messageId) {
    console.warn("⚠️ Message has no ID, skipping reaction.");
    return;
  }
  
  const msgBlock = document.querySelector(`[data-message-id="${messageId}"]`);
  if (!msgBlock || msgBlock.dataset.reacted) return;

  msgBlock.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
  await sleep(300);

  const reactBtn = Array.from(msgBlock.querySelectorAll("button")).find(btn => {
    const span = btn.querySelector("span");
    return span && span.textContent?.toLowerCase().includes("react");
  });

  if (!reactBtn) {
    console.log("⚠️ React button not found for message:", messageId);
    return;
  }

  reactBtn.click();
  await sleep(400);

  const popup = Array.from(document.querySelectorAll('.ant-popover-inner-content')).pop();
  if (!popup) {
    console.log("⚠️ Reaction popup not found for message:", messageId);
    return;
  }

  const emojiBtn = Array.from(popup.querySelectorAll('div.react-img')).find(div =>
    div.className.toLowerCase().includes(reactionName.toLowerCase())
  );

  if (emojiBtn) {
    emojiBtn.click();
    msgBlock.dataset.reacted = "true";
    console.log(`✅ Reacted to message ${messageId} with ${reactionName}`);
  } else {
    console.log("⚠️ Emoji not found for reaction:", reactionName);
  }
}

// ============================================================================
// MESSAGE DETECTION
// ============================================================================

function shouldIgnoreUser(username) {
  const normalizedUsername = username.toLowerCase();
  
  if (ignoreSelfMessages && normalizedUsername === botUserName.toLowerCase()) {
    return true;
  }
  
  const systemUsers = ['free4talk system', 'coffee notification'];
  if (systemUsers.includes(normalizedUsername)) {
    return true;
  }
  
  if (excludedUsernames.map(n => n.toLowerCase()).includes(normalizedUsername)) {
    return true;
  }
  
  return false;
}

function messageDetector() {
  messageDetectorInterval = setInterval(async () => {
    const messageBlocks = document.querySelectorAll('.system-message');
    messageBlocks.forEach(block => {
      const messageId = block.getAttribute('data-message-id') || '';
      
      // Skip if no message ID or already replied
      if (!messageId || hasRepliedTo(messageId)) {
        return;
      }

      const isPmMode = block.classList.contains('pm-mode');
      
      // Skip PM replies with quotes (already handled)
      if (isPmMode && block.querySelector('.quote-content')) {
        markAsReplied(messageId);
        return;
      }

      const message = block.querySelector('.text.main-content p');
      const userNameEl = block.querySelector('.name.primary span');
      const time = block.querySelector('.time span');
      
      if (!userNameEl || !message) return;

      const username = userNameEl.textContent.trim();
      const content = message.textContent.trim();
      
      if (shouldIgnoreUser(username)) {
        markAsReplied(messageId);
        return;
      }

      // **NEW: Extract reply/quote context**
      let replyToMessageId = null;
      let replyToUsername = null;
      let replyToContent = null;
      
      const quoteSection = block.querySelector('.text.quote.main-quote-content');
      if (quoteSection) {
        
        const quotedUserEl = quoteSection.querySelector('.quote-name span');
        if (quotedUserEl) {
          replyToUsername = quotedUserEl.textContent.trim();
        }
        
        
        const quotedMsgDiv = quoteSection.querySelector('.quote-content[data-message-id]');
        if (quotedMsgDiv) {
          replyToMessageId = quotedMsgDiv.getAttribute('data-message-id');
          const quotedContent = quotedMsgDiv.querySelector('p');
          if (quotedContent) {
            replyToContent = quotedContent.textContent.trim();
          }
        }
      }
      markAsReplied(messageId);
      
      chrome.runtime.sendMessage({
        type: 'NEW_MESSAGE',
        data: {
          username: username,
          content: content,
          timestamp: time ? time.textContent.trim() : new Date().toLocaleTimeString(),
          messageId: messageId,
          isPM: isPmMode,
          replyTo: replyToMessageId ? {
            messageId: replyToMessageId,
            username: replyToUsername,
            content: replyToContent
          } : null
        }
      }).catch(err => {
        console.error('Failed to send message to background:', err);
        repliedMessageIds.delete(messageId);
      });
    });
  }, 1000);
  
  isDetectorRunning = true;
  console.log('✅ Message detector started');
}


function startMessageDetector() {
  if (isDetectorRunning) {
    console.warn('⚠️ Message detector already running, skipping start');
    return;
  }
  messageDetector();
}

function stopMessageDetector() {
  if (messageDetectorInterval) {
    clearInterval(messageDetectorInterval);
    messageDetectorInterval = null;
    isDetectorRunning = false;
    console.log('🛑 Message detector stopped');
  }
}

// ============================================================================
// CLEANUP
// ============================================================================

window.addEventListener('beforeunload', () => {
  stopMessageDetector();
  saveRepliedIds(); // CRITICAL: Save before unload
  delete window.__FREE4TALK_BOT_LOADED__;
  console.log('🧹 Content script cleanup complete');
});

chrome.runtime.onMessage.addListener((request) => {
  if (request.type === 'EXTENSION_RELOADING') {
    stopMessageDetector();
    saveRepliedIds();
    delete window.__FREE4TALK_BOT_LOADED__;
  }
});

// Periodic cleanup to prevent memory bloat
setInterval(() => {
  if (repliedMessageIds.size > 500) {
    console.log('🧹 Pruning old message IDs...');
    const idsArray = Array.from(repliedMessageIds);
    repliedMessageIds = new Set(idsArray.slice(-500));
    saveRepliedIds();
  }
}, 300000); // Every 5 minutes

// ============================================================================
// ASYNC INITIALIZATION & START
// ============================================================================

(async function init() {
  console.log('🔄 Initializing GetSolace Free4Talk Bot...');
  
  // CRITICAL: Load replied IDs BEFORE starting detector
  await loadRepliedIds();
  
  // Now start the message detector
  startMessageDetector();
  
  console.log('✅ Bot initialization complete!');
})();
