export function messageDetector () {
    const lastMessage = null;
    
    const pollMessages = setInterval (() => {
        const messageContainer = document.querySelector('.translate-container');
        const message = document.querySelector('.message');
        message.computedStyleMap.border = '2px solid green';
    }, 500);
}


