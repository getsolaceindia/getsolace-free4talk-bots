(() => {
  "use strict";

  new class {
    constructor() {
      this.observer = null;
      this.isInitialized = false;
      this.retryCount = 0;
      this.maxRetries = 10;
      this.initialize();
    }

    async initialize() {
      console.log("🤖 Free4Talk Auto Reply Extension - Content Script Loading");

      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => {
          this.setupMessageTracking();
        });
      } else {
        this.setupMessageTracking();
      }

      chrome.runtime.onMessage.addListener(this.handleBackgroundMessage.bind(this));
      console.log("✅ Free4Talk content script initialized");
    }

    setupMessageTracking() {
      if (this.isOnRoomPage()) {
        this.waitForMessageContainer()
          .then(() => {
            this.startMessageObserver();
            this.isInitialized = true;
            console.log("✅ Message tracking started successfully");
          })
          .catch((e) => {
            console.error("❌ Failed to find message container:", e);
            this.retrySetup();
          });
      } else {
        console.log("❌ Not on a Free4Talk room page:", window.location.href);
      }
    }

    retrySetup() {
      if (this.retryCount < this.maxRetries) {
        this.retryCount++;
        console.log(`🔄 Retrying setup (${this.retryCount}/${this.maxRetries}) in 3 seconds...`);
        setTimeout(() => {
          this.setupMessageTracking();
        }, 3000);
      } else {
        console.error("❌ Max retries reached. Extension may not work on this page.");
      }
    }

    isOnRoomPage() {
      return (
        window.location.hostname.includes("free4talk.com") &&
        window.location.pathname.includes("/room/")
      );
    }

    async waitForMessageContainer() {
      return new Promise((resolve, reject) => {
        let attempts = 0;

        const tryFind = () => {
          attempts++;

          const selectors = [
            ".translate-container",
            ".messages-container",
            ".message-container",
            ".chat-container",
            '[class*="translate"]',
            '[class*="message"]'
          ];

          let container = null;
          for (const selector of selectors) {
            container = document.querySelector(selector);
            if (container) break;
          }

          if (container) {
            resolve(container);
          } else if (attempts >= 30) {
            console.error("❌ Available elements on page:");
            const elements = document.querySelectorAll("*[class]");
            const classList = Array.from(elements)
              .map(el => el.className)
              .filter(Boolean);
            console.log("Classes found:", [...new Set(classList)].slice(0, 20));
            reject(new Error("Message container not found after 30 attempts"));
          } else {
            setTimeout(tryFind, 1000);
          }
        };

        tryFind();
      });
    }

    startMessageObserver() {
      const selectors = [
        ".translate-container",
        ".messages-container",
        ".message-container",
        ".chat-container",
        '[class*="translate"]',
        '[class*="message"]'
      ];

      let container = null;
      let usedSelector = "";

      for (const selector of selectors) {
        container = document.querySelector(selector);
        if (container) {
          usedSelector = selector;
          break;
        }
      }

      if (container) {
        if (this.observer) this.observer.disconnect();

        this.observer = new MutationObserver(mutations => {
          for (const mutation of mutations) {
            if (mutation.type === "childList") {
              mutation.addedNodes.forEach(node => {
                if (node instanceof HTMLDivElement && node.id) {
                  this.processNewMessage(node);
                }
              });
            }
          }
        });

        this.observer.observe(container, { childList: true, subtree: true });
      } else {
        console.error("❌ Message container not found in startMessageObserver");
      }
    }

    processNewMessage(element) {
      try {
        const systemMsg = element.querySelector(".system span.ant-typography.ant-typography-secondary");
        if (systemMsg instanceof HTMLSpanElement) {
          const strongEl = element.querySelector(".system span.ant-typography.ant-typography-secondary strong");
          const messageData = {
            content: systemMsg.innerText,
            username: strongEl?.textContent || "System",
            isPM: false,
            type: "notification",
            isThread: false,
            quotes: []
          };
          this.sendMessageToBackground(messageData);
          return;
        }

        const isPM = element.firstElementChild?.classList.contains("pm-mode") || false;
        const username = element.querySelector(".user .name span")?.textContent;
        const time = element.querySelector(".user .time")?.textContent;

        if (!username) {
          console.log("⚠️ No username found, skipping message");
          return;
        }

        const textBlocks = Array.from(element.querySelectorAll(".text"));
        if (!textBlocks.length) return;

        const mainContent = element.querySelector(".text.main-content .html");
        if (!mainContent) return;

        const quotes = textBlocks
          .map((block, index) => {
            if (block.classList.contains("quote")) {
              return {
                quotedUsername: this.getUserNameFromQuote(block),
                quotedContent: this.getContentFromQuote(block),
                messageIndex: index,
                isLastInThread: index === textBlocks.length - 2
              };
            }
            return null;
          })
          .filter(q => q !== null);

        const messageObj = {
          username,
          content: mainContent.innerHTML,
          quotes,
          isThread: quotes.length > 0,
          type: "message",
          isPM,
          messageId: isPM ? "pm" : element.id,
          time: time || ""
        };

        this.sendMessageToBackground(messageObj);
      } catch (error) {
        console.error("Error processing message:", error);
      }
    }

    getUserNameFromQuote(block) {
      const quoteName = block.querySelector(".quote-name");
      if (!quoteName) return "Unknown";

      const copy = quoteName.cloneNode(true);
      const avatar = copy.querySelector(".ant-avatar");
      if (avatar) avatar.remove();

      return copy.textContent?.trim() || "Unknown";
    }

    getContentFromQuote(block) {
      const content = block.querySelector(".quote-content .html");
      return content ? content.innerHTML || "Unknown" : "";
    }

    sendMessageToBackground(message) {
      chrome.runtime
        .sendMessage({ type: "NEW_MESSAGE", data: message })
        .then(response => {
          console.log("✅ Background script response:", response);
        })
        .catch(err => {
          console.error("❌ Error sending message to background:", err);
        });
    }

    async handleBackgroundMessage(request, sender, sendResponse) {
      try {
        if (request.type === "SEND_REPLY") {
          await this.sendReply(request.data.text, request.data.originalMessage);
        } else {
          console.warn("Unknown message from background:", request);
        }
      } catch (error) {
        console.error("Error handling background message:", error);
      }
      sendResponse({ success: true });
    }

    async sendReply(text, originalMessage) {
      try {
        const textarea = document.querySelector("textarea");
        if (!textarea) {
          console.error("Textarea not found");
          return;
        }

        if (originalMessage.messageId && originalMessage.messageId !== "pm") {
          await this.setupReplyToMessage(originalMessage.messageId);
        }

        textarea.value = text;
        textarea.dispatchEvent(new Event("input", { bubbles: true }));

        await new Promise(res => setTimeout(res, 100));

        const sendBtn = document.querySelector('.input-send-box button[type="button"]');
        if (sendBtn) {
          sendBtn.click();
          console.log("Reply sent:", text);
        } else {
          console.error("Send button not found");
        }
      } catch (error) {
        console.error("Error sending reply:", error);
      }
    }

    async setupReplyToMessage(messageId) {
      try {
        const messageEl = document.querySelector(`div[data-message-id="${messageId}"]`);
        if (!messageEl) {
          console.log("Message element not found for reply setup");
          return;
        }

        const hoverEvent = new MouseEvent("mouseenter", { bubbles: true });
        messageEl.dispatchEvent(hoverEvent);

        await new Promise(res => setTimeout(res, 500));

        const replyBtn = Array.from(messageEl.querySelectorAll("button")).find(btn => {
          const span = btn.querySelector("span");
          return span && span.textContent?.includes("Reply");
        });

        if (replyBtn && replyBtn.offsetParent !== null) {
          replyBtn.click();
          console.log("Reply setup successful for message:", messageId);
        } else {
          console.log("Reply button not found or not visible");
        }
      } catch (error) {
        console.error("Error setting up reply:", error);
      }
    }
  };
})();
